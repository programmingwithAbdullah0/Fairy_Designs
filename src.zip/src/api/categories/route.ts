
// // src/app/api/categories/route.ts
// import { NextResponse } from "next/server"
// import { client, writeClient } from "@/sanity/lib/client"

// export async function GET() {
//   try {
//     const categories = await client.fetch(
//       `*[_type == "category"]{
//         _id,
//         name,
//         "slug": slug.current,
//         description
//       } | order(name asc)`
//     )

//     return NextResponse.json({ success: true, categories })
//   } catch (error) {
//     console.error("Error fetching categories:", error)
//     return NextResponse.json(
//       { success: false, error: "Failed to fetch categories" },
//       { status: 500 }
//     )
//   }
// }

// export async function POST(req: Request) {
//   if (!process.env.SANITY_API_WRITE_TOKEN) {
//     return NextResponse.json(
//       { success: false, error: "Missing SANITY_API_WRITE_TOKEN" },
//       { status: 500 }
//     )
//   }

//   try {
//     const { name, slug, description } = await req.json()

//     if (!name || !slug) {
//       return NextResponse.json(
//         { success: false, error: "Name and slug are required" },
//         { status: 400 }
//       )
//     }

//     const doc = await writeClient.create({
//       _type: "category",
//       name,
//       slug: { _type: "slug", current: slug },
//       description: description || "",
//     })

//     return NextResponse.json({ success: true, category: doc })
//   } catch (error) {
//     console.error("Error creating category:", error)
//     return NextResponse.json(
//       { success: false, error: "Failed to create category" },
//       { status: 500 }
//     )
//   }
// }

// // ← YAHAN PASTE KARO (file ke bilkul end mein, last } ke baad)

// export async function DELETE(request: Request) {
//   const { searchParams } = new URL(request.url)
//   const id = searchParams.get('id')

//   if (!id) {
//     return NextResponse.json({ error: 'ID required' }, { status: 400 })
//   }

//   try {
//     await writeClient.delete(id)
//     return NextResponse.json({ success: true })
//   } catch (error) {
//     console.error('Delete category error:', error)
//     return NextResponse.json({ error: 'Failed to delete category' }, { status: 500 })
//   }
// }

// // src/app/api/categories/route.ts
// import { NextResponse } from "next/server"
// import { client, writeClient } from "@/sanity/lib/client"

// // GET - List all categories
// export async function GET() {
//   try {
//     const categories = await client.fetch(
//       `*[_type == "category"]{
//         _id,
//         name,
//         "slug": slug.current,
//         description
//       } | order(name asc)`
//     )

//     return NextResponse.json({ success: true, categories })
//   } catch (error) {
//     console.error("Error fetching categories:", error)
//     return NextResponse.json(
//       { success: false, error: "Failed to fetch categories" },
//       { status: 500 }
//     )
//   }
// }

// // POST - Add new category
// export async function POST(req: Request) {
//   // ← YE CHANGE KIYA (galat name tha pehle)
//   if (!process.env.NEXT_PUBLIC_SANITY_API_TOKEN) {
//     return NextResponse.json(
//       { success: false, error: "Unauthorized - Missing token" },
//       { status: 401 }
//     )
//   }

//   try {
//     const { name, slug, description } = await req.json()

//     if (!name || !slug) {
//       return NextResponse.json(
//         { success: false, error: "Name and slug are required" },
//         { status: 400 }
//       )
//     }

//     const doc = await writeClient.create({
//       _type: "category",
//       name,
//       slug: { _type: "slug", current: slug },
//       description: description || "",
//     })

//     return NextResponse.json({ success: true, category: doc })
//   } catch (error: any) {
//     console.error("Error creating category:", error)
//     return NextResponse.json(
//       { success: false, error: error.message || "Failed to create category" },
//       { status: 500 }
//     )
//   }
// }

// // DELETE - Delete category (YE PURA FUNCTION ADD KIYA + TOKEN CHECK BHI)
// export async function DELETE(request: Request) {
//   // ← TOKEN CHECK ADD KIYA (yeh missing tha isliye 405 aa raha tha)
//   if (!process.env.NEXT_PUBLIC_SANITY_API_TOKEN) {
//     return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
//   }

//   const { searchParams } = new URL(request.url)
//   const id = searchParams.get('id')

//   if (!id) {
//     return NextResponse.json({ error: 'ID required' }, { status: 400 })
//   }

//   try {
//     await writeClient.delete(id)
//     return NextResponse.json({ success: true, message: "Category deleted successfully" })
//   } catch (error: any) {
//     console.error('Delete category error:', error)
//     return NextResponse.json(
//       { error: error.message || 'Failed to delete category' },
//       { status: 500 }
//     )
//   }
// }

// src/app/api/categories/route.ts
// import { NextResponse } from "next/server"
// import { client } from "@/sanity/lib/client"

// export async function GET() {
//   try {
//     const categories = await client.fetch(`
//       *[_type == "category"]{
//         _id,
//         name,
//         "slug": slug.current,
//         description
//       } | order(name asc)
//     `)
//     return NextResponse.json({ success: true, categories })
//   } catch (error) {
//     return NextResponse.json({ success: false, error: "Failed to fetch" }, { status: 500 })
//   }
// }

// src/app/api/categories/route.ts
// 1 file mein sab kuch: GET + POST + PUT + DELETE

import { NextResponse } from "next/server"
import { client, writeClient } from "@/sanity/lib/client"

// 1. GET → List all categories
export async function GET() {
  const categories = await client.fetch(`
    *[_type == "category"] | order(name asc) {
      _id, name, "slug": slug.current, description
    }
  `)
  return NextResponse.json(categories)
}

// 2. POST → Add new category
export async function POST(req: Request) {
  if (!process.env.NEXT_PUBLIC_SANITY_API_TOKEN) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const { name, slug, description } = await req.json()
  if (!name || !slug) return NextResponse.json({ error: "Name & slug required" }, { status: 400 })

  const result = await writeClient.create({
    _type: "category",
    name,
    slug: { _type: "slug", current: slug },
    description: description || ""
  })

  return NextResponse.json({ success: true, category: result })
}

// 3. PUT → Edit category (id query mein bhejna)
export async function PUT(req: Request) {
  if (!process.env.NEXT_PUBLIC_SANITY_API_TOKEN) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const { searchParams } = new URL(req.url)
  const id = searchParams.get("id")
  if (!id) return NextResponse.json({ error: "ID required" }, { status: 400 })

  const { name, slug, description } = await req.json()
  if (!name || !slug) return NextResponse.json({ error: "Name & slug required" }, { status: 400 })

  const updated = await writeClient
    .patch(id)
    .set({
      name,
      slug: { _type: "slug", current: slug },
      description: description || ""
    })
    .commit()

  return NextResponse.json({ success: true, category: updated })
}

// 4. DELETE → Delete category (id query mein bhejna)
export async function DELETE(req: Request) {
  if (!process.env.NEXT_PUBLIC_SANITY_API_TOKEN) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const { searchParams } = new URL(req.url)
  const id = searchParams.get("id")
  if (!id) return NextResponse.json({ error: "ID required" }, { status: 400 })

  await writeClient.delete(id)
  return NextResponse.json({ success: true })
}

// YE LINE BILKUL NEeche ADD KAR DO (file ke end mein)
export const dynamic = 'force-dynamic'   // <-- yehi line 405 ka ilaaj hai
export const revalidate = 0            // <-- yehi line bhi daal do