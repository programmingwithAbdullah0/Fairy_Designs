// // app/api/products/[id]/route.ts
// import { NextRequest, NextResponse } from 'next/server'
// import { client as sanityClient } from '../../../../sanity/lib/client'


// export async function DELETE(
//   request: NextRequest,
//   { params }: { params: { id: string } }
// ) {
//   try {
//     const productId = params.id

//     // Delete product from Sanity
//     await sanityClient.delete(productId)

//     return NextResponse.json({
//       success: true,
//       message: 'Product deleted successfully!'
//     })

//   } catch (error: any) {
//     console.error('Error deleting product:', error)
//     return NextResponse.json(
//       { 
//         success: false, 
//         error: error.message || 'Failed to delete product' 
//       },
//       { status: 500 }
//     )
//   }
// }

// export async function GET(
//   request: NextRequest,
//   { params }: { params: { id: string } }
// ) {
//   try {
//     const productId = params.id

//     const query = `*[_type == "product" && _id == $id][0]{
//       _id,
//       name,
//       slug,
//       priceMin,
//       priceMax,
//       description,
//       category->{_id, name},
//       image
//     }`

//     const product = await sanityClient.fetch(query, { id: productId })

//     if (!product) {
//       return NextResponse.json(
//         { success: false, error: 'Product not found' },
//         { status: 404 }
//       )
//     }

//     return NextResponse.json({
//       success: true,
//       product
//     })
//   } catch (error: any) {
//     console.error('Error fetching product:', error)
//     return NextResponse.json(
//       { 
//         success: false, 
//         error: error.message || 'Failed to fetch product' 
//       },
//       { status: 500 }
//     )
//   }
// }

// export async function PUT(
//   request: NextRequest,
//   { params }: { params: { id: string } }
// ) {
//   try {
//     const productId = params.id
//     const data = await request.json()

//     // Format slug correctly for Sanity
//     const updatedProduct: any = { ...data }
//     if (data.slug && typeof data.slug === 'string') {
//       updatedProduct.slug = {
//         _type: 'slug',
//         current: data.slug,
//       }
//     }

//     const result = await sanityClient
//       .patch(productId)
//       .set(updatedProduct)
//       .commit()

//     return NextResponse.json({
//       success: true,
//       message: 'Product updated successfully!',
//       product: result
//     })

//   } catch (error: any) {
//     console.error('Error updating product:', error)
//     return NextResponse.json(
//       { 
//         success: false, 
//         error: error.message || 'Failed to update product' 
//       },
//       { status: 500 }
//     )
//   }
// }

// src/app/api/products/[id]/route.ts
import { NextResponse } from "next/server"
import { client, writeClient } from "@/sanity/lib/client"

interface RouteContext {
  params: { id: string }
}

export async function GET(_req: Request, { params }: RouteContext) {
  const { id } = params

  try {
    const product = await client.fetch(
      `*[_type == "product" && _id == $id][0]{
        _id,
        name,
        priceMin,
        priceMax,
        description,
        image,
        "slug": slug.current,
        category->{_id, name}
      }`,
      { id }
    )

    if (!product) {
      return NextResponse.json(
        { success: false, error: "Product not found" },
        { status: 404 }
      )
    }

    return NextResponse.json({ success: true, product })
  } catch (error) {
    console.error("Error fetching product:", error)
    return NextResponse.json(
      { success: false, error: "Failed to fetch product" },
      { status: 500 }
    )
  }
}

export async function PUT(req: Request, { params }: RouteContext) {
  if (!process.env.SANITY_API_WRITE_TOKEN) {
    return NextResponse.json(
      { success: false, error: "Missing SANITY_API_WRITE_TOKEN" },
      { status: 500 }
    )
  }

  const { id } = params

  try {
    const body = await req.json()
    const { name, slug, priceMin, priceMax, description, category } = body

    if (!name || !slug || priceMin == null || priceMax == null) {
      return NextResponse.json(
        { success: false, error: "Missing required fields" },
        { status: 400 }
      )
    }

    const patch: any = {
      name,
      slug: { _type: "slug", current: slug },
      priceMin,
      priceMax,
      description: description || "",
    }

    if (category) {
      // expects { _type: "reference", _ref: "categoryId" }
      patch.category = category
    } else {
      patch.category = null
    }

    const updated = await writeClient.patch(id).set(patch).commit()

    return NextResponse.json({ success: true, product: updated })
  } catch (error) {
    console.error("Error updating product:", error)
    return NextResponse.json(
      { success: false, error: "Failed to update product" },
      { status: 500 }
    )
  }
}

export async function DELETE(_req: Request, { params }: RouteContext) {
  if (!process.env.SANITY_API_WRITE_TOKEN) {
    return NextResponse.json(
      { success: false, error: "Missing SANITY_API_WRITE_TOKEN" },
      { status: 500 }
    )
  }

  const { id } = params

  try {
    await writeClient.delete(id)
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error deleting product:", error)
    return NextResponse.json(
      { success: false, error: "Failed to delete product" },
      { status: 500 }
    )
  }
}
