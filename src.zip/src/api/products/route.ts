
// // app/api/products/route.ts
// import { NextRequest, NextResponse } from 'next/server'
// import { client as sanityClient } from '../../../sanity/lib/client'
// export async function POST(request: NextRequest) {
//   try {
//     const formData = await request.formData()
    
//     const name = formData.get('name') as string
//     const slug = formData.get('slug') as string
//     const priceMin = parseFloat(formData.get('priceMin') as string)
//     const priceMax = parseFloat(formData.get('priceMax') as string)
//     const description = formData.get('description') as string
//     const category = formData.get('category') as string
//     const imageFile = formData.get('image') as File

//     // Validation
//     if (!name || !slug || !priceMin || !priceMax) {
//       return NextResponse.json(
//         { success: false, error: 'Missing required fields' },
//         { status: 400 }
//       )
//     }

//     // Upload image to Sanity if provided
//     let imageAsset = null
//     if (imageFile) {
//       const imageBuffer = await imageFile.arrayBuffer()
//       const buffer = Buffer.from(imageBuffer)
      
//       imageAsset = await sanityClient.assets.upload('image', buffer, {
//         filename: imageFile.name,
//       })
//     }

//     // Create product in Sanity
//     const product = {
//       _type: 'product',
//       name,
//       slug: {
//         _type: 'slug',
//         current: slug,
//       },
//       priceMin,
//       priceMax,
//       description,
//       ...(category && {
//         category: {
//           _type: 'reference',
//           _ref: category,
//         },
//       }),
//       ...(imageAsset && {
//         image: {
//           _type: 'image',
//           asset: {
//             _type: 'reference',
//             _ref: imageAsset._id,
//           },
//         },
//       }),
//     }

//     const result = await sanityClient.create(product)

//     return NextResponse.json({
//       success: true,
//       message: 'Product created successfully!',
//       product: result
//     })

//   } catch (error: any) {
//     console.error('Error creating product:', error)
//     return NextResponse.json(
//       { 
//         success: false, 
//         error: error.message || 'Failed to create product' 
//       },
//       { status: 500 }
//     )
//   }
// }

// export async function GET(request: NextRequest) {
//   try {
//     const { searchParams } = new URL(request.url);
//     const category = searchParams.get('category');

//     let query;
//     let params = {};

//     if (category) {
//       if (category === 'uncategorized') {
//         // Fetch products without a category
//         query = `*[_type == "product" && !defined(category)]{
//           _id,
//           name,
//           slug,
//           priceMin,
//           priceMax,
//           description,
//           category->{_id, name},
//           image
//         }`;
//       } else {
//         // Fetch products with the selected category
//         query = `*[_type == "product" && category._ref == $categoryId]{
//           _id,
//           name,
//           slug,
//           priceMin,
//           priceMax,
//           description,
//           category->{_id, name},
//           image
//         }`;
//         params = { categoryId: category };
//       }
//     } else {
//       // Fetch all products
//       query = `*[_type == "product"]{
//         _id,
//         name,
//         slug,
//         priceMin,
//         priceMax,
//         description,
//         category->{_id, name},
//         image
//       }`;
//     }

//     const products = await sanityClient.fetch(query, params);

//     return NextResponse.json({
//       success: true,
//       products
//     })
//   } catch (error: any) {
//     console.error('Error fetching products:', error)
//     return NextResponse.json(
//       { 
//         success: false, 
//         error: error.message || 'Failed to fetch products' 
//       },
//       { status: 500 }
//     )
//   }
// }

// src/app/api/products/route.ts
import { NextResponse } from "next/server"
import { client, writeClient } from "@/sanity/lib/client"

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url)
    const category = searchParams.get("category")

    let query = `*[_type == "product"`
    const params: Record<string, any> = {}

    if (category && category !== "all") {
      if (category === "uncategorized") {
        query += ` && !defined(category)`
      } else {
        query += ` && category._ref == $categoryId`
        params.categoryId = category
      }
    }

    query += `]{
      _id,
      name,
      priceMin,
      priceMax,
      description,
      image,
      "slug": slug.current,
      category->{_id, name}
    } | order(_createdAt desc)`

    const products = await client.fetch(query, params)

    return NextResponse.json({ success: true, products })
  } catch (error) {
    console.error("Error fetching products:", error)
    return NextResponse.json(
      { success: false, error: "Failed to fetch products" },
      { status: 500 }
    )
  }
}

export async function POST(req: Request) {
  if (!process.env.SANITY_API_WRITE_TOKEN) {
    return NextResponse.json(
      { success: false, error: "Missing SANITY_API_WRITE_TOKEN" },
      { status: 500 }
    )
  }

  try {
    const formData = await req.formData()

    const name = formData.get("name") as string | null
    const slug = formData.get("slug") as string | null
    const priceMin = formData.get("priceMin") as string | null
    const priceMax = formData.get("priceMax") as string | null
    const description = formData.get("description") as string | null
    const categoryId = formData.get("category") as string | null
    const image = formData.get("image") as File | null

    if (!name || !slug || !priceMin || !priceMax) {
      return NextResponse.json(
        { success: false, error: "Missing required fields" },
        { status: 400 }
      )
    }

    let imageField: any = undefined

    if (image) {
      const asset = await writeClient.assets.upload("image", image, {
        filename: image.name,
        contentType: image.type,
      })

      imageField = {
        _type: "image",
        asset: {
          _type: "reference",
          _ref: asset._id,
        },
      }
    }

    const doc: any = {
      _type: "product",
      name,
      slug: { _type: "slug", current: slug },
      priceMin: Number(priceMin),
      priceMax: Number(priceMax),
      description: description || "",
    }

    if (categoryId) {
      doc.category = {
        _type: "reference",
        _ref: categoryId,
      }
    }

    if (imageField) {
      doc.image = imageField
    }

    const created = await writeClient.create(doc)

    return NextResponse.json({ success: true, product: created })
  } catch (error) {
    console.error("Error creating product:", error)
    return NextResponse.json(
      { success: false, error: "Failed to create product" },
      { status: 500 }
    )
  }
}
