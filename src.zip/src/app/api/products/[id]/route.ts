
// app/api/products/route.ts
// import { NextResponse } from "next/server";
// import { client, writeClient } from "@/sanity/lib/client";

// export async function GET(req: Request) {
//   try {
//     const { searchParams } = new URL(req.url);
//     const categoryId = searchParams.get("category") || null;

//     const query = `
//       *[_type == "product"
//         ${categoryId && categoryId !== "all" ? "&& category._ref == $categoryId" : ""}
//       ]{
//         _id,
//         name,
//         "slug": slug.current,
//         priceMin,
//         priceMax,
//         description,
//         image,
//         category->{_id, name}
//       } | order(_createdAt desc)
//     `;

//     const products = await client.fetch(query, categoryId && categoryId !== "all" ? { categoryId } : {});

//     return NextResponse.json({ success: true, products });
//   } catch (error: any) {
//     console.error("Error fetching products:", error);
//     return NextResponse.json(
//       { success: false, error: "Error fetching products" },
//       { status: 500 }
//     );
//   }
// }

// export async function POST(req: Request) {
//   try {
//     // New product form se multipart/form-data aa raha hai
//     const contentType = req.headers.get("content-type") || "";

//     let body: any = {};
//     let imageFile: Blob | null = null;

//     if (contentType.includes("multipart/form-data")) {
//       const form = await req.formData();
//       body = {
//         name: form.get("name"),
//         slug: form.get("slug"),
//         priceMin: form.get("priceMin"),
//         priceMax: form.get("priceMax"),
//         description: form.get("description"),
//         category: form.get("category"),
//       };
//       const img = form.get("image");
//       if (img instanceof Blob) {
//         imageFile = img;
//       }
//     } else {
//       body = await req.json();
//     }

//     const { name, slug, priceMin, priceMax, description, category } = body;

//     if (!name || !slug) {
//       return NextResponse.json(
//         { success: false, error: "Name and slug are required" },
//         { status: 400 }
//       );
//     }

//     const doc: any = {
//       _type: "product",
//       name,
//       slug: { _type: "slug", current: String(slug) },
//       priceMin: Number(priceMin),
//       priceMax: Number(priceMax),
//       description: description || "",
//     };

//     if (category) {
//       doc.category = {
//         _type: "reference",
//         _ref: String(category),
//       };
//     }

//     // image upload to Sanity
//     if (imageFile) {
//       const buffer = Buffer.from(await imageFile.arrayBuffer());
//       const asset = await writeClient.assets.upload("image", buffer, {
//         filename: "product-image",
//         contentType: imageFile.type || "image/*",
//       });

//       doc.image = {
//         _type: "image",
//         asset: {
//           _type: "reference",
//           _ref: asset._id,
//         },
//       };
//     }

//     const created = await writeClient.create(doc);

//     return NextResponse.json({
//       success: true,
//       product: created,
//     });
//   } catch (error: any) {
//     console.error("Error creating product:", error);
//     return NextResponse.json(
//       { success: false, error: "Error creating product" },
//       { status: 500 }
//     );
//   }
// }

// app/api/products/[id]/route.ts
import { NextResponse } from "next/server";
import { client, writeClient } from "@/sanity/lib/client";

interface Params {
  params: { id: string };
}

export async function GET(req: Request, { params }: Params) {
  try {
    const product = await client.getDocument(params.id);

    if (!product) {
      return NextResponse.json(
        { success: false, error: "Product not found" },
        { status: 404 }
      );
    }

    return NextResponse.json({ success: true, product });
  } catch (error: any) {
    console.error("Error fetching product:", error);
    return NextResponse.json(
      { success: false, error: "Error fetching product" },
      { status: 500 }
    );
  }
}

export async function PUT(req: Request, { params }: Params) {
  try {
    const id = params.id;
    const body = await req.json();

    const { name, slug, priceMin, priceMax, description, category } = body;

    const patch: any = {
      name,
      slug: { _type: "slug", current: String(slug) },
      priceMin: Number(priceMin),
      priceMax: Number(priceMax),
      description: description || "",
    };

    if (category) {
      // frontend se already {_type:'reference', _ref:'...'} aa raha hai
      patch.category = category;
    } else {
      patch.category = null;
    }

    const updated = await writeClient.patch(id).set(patch).commit();

    return NextResponse.json({ success: true, product: updated });
  } catch (error: any) {
    console.error("Error updating product:", error);
    return NextResponse.json(
      { success: false, error: "Error updating product" },
      { status: 500 }
    );
  }
}

export async function DELETE(req: Request, { params }: Params) {
  try {
    const id = params.id;
    await writeClient.delete(id);

    return NextResponse.json({ success: true });
  } catch (error: any) {
    console.error("Error deleting product:", error);
    return NextResponse.json(
      { success: false, error: "Error deleting product" },
      { status: 500 }
    );
  }
}
