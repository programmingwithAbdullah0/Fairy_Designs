// src/app/api/categories/route.ts
// import { NextResponse } from "next/server"
// import { client, writeClient } from "@/sanity/lib/client"

// export async function GET() {
//   try {
//     const categories = await client.fetch(
//       `*[_type == "category"]{
//         _id,
//         name,
//         "slug": slug.current,
//         description
//       } | order(name asc)`
//     )

//     return NextResponse.json({ success: true, categories })
//   } catch (error) {
//     console.error("Error fetching categories:", error)
//     return NextResponse.json(
//       { success: false, error: "Failed to fetch categories" },
//       { status: 500 }
//     )
//   }
// }

// export async function POST(req: Request) {
//   if (!process.env.SANITY_API_WRITE_TOKEN) {
//     return NextResponse.json(
//       { success: false, error: "Missing SANITY_API_WRITE_TOKEN" },
//       { status: 500 }
//     )
//   }

//   try {
//     const { name, slug, description } = await req.json()

//     if (!name || !slug) {
//       return NextResponse.json(
//         { success: false, error: "Name and slug are required" },
//         { status: 400 }
//       )
//     }

//     const doc = await writeClient.create({
//       _type: "category",
//       name,
//       slug: { _type: "slug", current: slug },
//       description: description || "",
//     })

//     return NextResponse.json({ success: true, category: doc })
//   } catch (error) {
//     console.error("Error creating category:", error)
//     return NextResponse.json(
//       { success: false, error: "Failed to create category" },
//       { status: 500 }
//     )
//   }
// }

// app/api/categories/route.ts
import { NextResponse } from "next/server";
import { client, writeClient } from "@/sanity/lib/client";

export async function GET() {
  try {
    const categories = await client.fetch(
      `*[_type == "category"]{
        _id,
        name,
        "slug": slug.current,
        description
      } | order(name asc)`
    );

    return NextResponse.json({ success: true, categories });
  } catch (error: any) {
    console.error("Error fetching categories:", error);
    return NextResponse.json(
      { success: false, error: "Error fetching categories" },
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { name, slug, description } = body;

    if (!name || !slug) {
      return NextResponse.json(
        { success: false, error: "Name and slug are required" },
        { status: 400 }
      );
    }

    const doc = {
      _type: "category",
      name,
      slug: { _type: "slug", current: String(slug) },
      description: description || "",
    };

    const created = await writeClient.create(doc);

    return NextResponse.json({ success: true, category: created });
  } catch (error: any) {
    console.error("Error creating category:", error);
    return NextResponse.json(
      { success: false, error: "Error creating category" },
      { status: 500 }
    );
  }
}
