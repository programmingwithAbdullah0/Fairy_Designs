// app/api/categories/[id]/route.ts
import { NextResponse } from "next/server";
import { writeClient } from "@/sanity/lib/client";

interface Params {
  params: { id: string };
}

export async function PUT(req: Request, { params }: Params) {
  try {
    const id = params.id;
    const body = await req.json();
    const { name, slug, description } = body;

    const patch: any = {
      name,
      slug: { _type: "slug", current: String(slug) },
      description: description || "",
    };

    const updated = await writeClient.patch(id).set(patch).commit();

    return NextResponse.json({ success: true, category: updated });
  } catch (error: any) {
    console.error("Error updating category:", error);
    return NextResponse.json(
      { success: false, error: "Error updating category" },
      { status: 500 }
    );
  }
}

export async function DELETE(req: Request, { params }: Params) {
  try {
    const id = params.id;

    // Direct delete – agar products is category se linked hon ge to Sanity error de sakta hai
    await writeClient.delete(id);

    return NextResponse.json({ success: true });
  } catch (error: any) {
    console.error("Error deleting category:", error);
    return NextResponse.json(
      { success: false, error: "Failed to delete category" },
      { status: 500 }
    );
  }
}
